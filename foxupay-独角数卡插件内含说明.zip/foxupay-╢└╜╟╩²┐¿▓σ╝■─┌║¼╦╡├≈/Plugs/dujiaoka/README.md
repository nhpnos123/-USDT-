## `dujiaoka`对接`FOXUPAY`

### 1. 将插件复制到`dujiaoka`对应目录

### 2. 将`database`内的`add.sql`内的sql语句，复制到你的mysql执行（也可以跳过这一步手动添加）

### 3. 到`dujiaoka`后台-**配置**-**支付配置**中`添加/编辑`支付方式

注意事项

1. 所有内容前后都不允许有空格
2. 支付名称、支付标识、支付处理路由，请按图填写

请参考此图填写
<img src="../../dujiaoka-foxupay.jpg" alt="dujiaoka支付方式配置"/>