## 1panel部署独角数卡

### 1、1panel安装

官网：https://1panel.cn/
根据官网描述安装

面板安装成功后，前往应用商店，安装mysql、redis

导入数据库sql

### 2、安装php7.4

#### 2.1 添加php7.4源

```
sudo yum install -y epel-release yum-utils
```

```
sudo yum install -y http://rpms.remirepo.net/enterprise/remi-release-7.rpm
```

```
sudo yum-config-manager --enable remi-php74
```

#### 2.2 安装php插件

```
sudo yum install php php-cli php-fpm php-mysql php-zip php-devel php-gd php-mbstring php-curl php-xml php-pear
php-bcmath -y
```

#### 2.3 安装php扩展fileinfo、redis、phpzip、opcache

```
yum install php-fileinfo php-pecl-redis php-pecl-zip php-opcache -y
```

#### 2.4 启动php

```
systemctl start php-fpm
```

### 3、安装OpenResty

#### 3.1 安装OpenResty

进入 `应用商店` 找到 `OpenResty` 点击 安装 即可

#### 3.2 创建网站

进入 `网站` -> `网站` -> 点击 `创建网站`

![imgs/1.png](imgs/1.png)

`静态网站` ->`主域名`：填入你的域名 -> 点击 `确认` 即可

![imgs/2.png](imgs/2.png)

回到网站列表 -> 点击 `配置`

![imgs/3.png](imgs/3.png)

网站目录 -> 点击目录

![imgs/4.png](imgs/4.png)

点击 `index`

![imgs/5.png](imgs/5.png)

删除 `index.html`

![imgs/6.png](imgs/6.png)

下载安装包

发行版本下载：https://github.com/assimon/dujiaoka/releases

上传 `dijiaoka` 代码压缩包

![imgs/7.png](imgs/7.png)
![imgs/8.png](imgs/8.png)
![imgs/9.png](imgs/9.png)
![imgs/10.png](imgs/10.png)

上传完成后，点击`解压`，解压文件

![imgs/11.png](imgs/11.png)

修改 `dujiaoka` 目录权限为 0777

![imgs/15.png](imgs/15.png)
![imgs/16.png](imgs/16.png)

解压后，回到网站，编辑网站目录

![imgs/12.png](imgs/12.png)

添加伪静态，选择 `laravel5` ,并覆盖代码

![imgs/13.png](imgs/13.png)

```
        location / {
            try_files $uri $uri/ /index.php?$query_string;
        }
        location ~ \.php($|/) {
            # 设置项目根目录 chroot
            set $PROJECT_NAME "/opt/1panel/apps/openresty/openresty/www/sites/www.daguoli.cn/index/dujiaoka/public";
            include fastcgi_params;
            fastcgi_pass 127.0.0.1:9000; # 基于本地回环地址
            fastcgi_index index.php;
            fastcgi_split_path_info ^(.+\.php)(.*)$;
            fastcgi_param SCRIPT_FILENAME $PROJECT_NAME$fastcgi_script_name;
        }

```

![imgs/13.png](imgs/14.png)

### 4 访问服务器的ip,配置数据库、redis等数据，点击安装即可

### 5 关闭Debug

```
cd /usr/share/nginx/html/dujiaoka
```

```
vim .env
```

```
APP_DEBUG=false   # true改为false
```

### 5、配置进程守护

根据文档说明安装supervisor

https://1panel.cn/docs/user_manual/toolbox/supervisor/

安装完成后回1panel面板->工具箱->进程守护->创建守护进程

```
名称：任意
启动用户：root
运行目录：/usr/share/nginx/html/dujiaoka
启动命令：php artisan queue:work --tries=3
进程数量：2，根据服务器配置
```
